package com.usian.feign;

import com.usian.pojo.SearchItem;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@FeignClient(value = "usian-search-service")
public interface SearchItemFeign {

    @RequestMapping("/service/search/importAll")
    Boolean importAll();

    @RequestMapping("service/search/selectByQ")
    List<SearchItem> selectByQ(@RequestParam String q, @RequestParam Long page,@RequestParam Integer pagesize);


}
