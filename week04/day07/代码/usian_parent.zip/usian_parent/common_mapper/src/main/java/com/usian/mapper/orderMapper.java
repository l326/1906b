package com.usian.mapper;

import com.usian.pojo.TbOrder;

import java.util.List;

public interface orderMapper {
    List<TbOrder> selectOvertimeOrder();
}
