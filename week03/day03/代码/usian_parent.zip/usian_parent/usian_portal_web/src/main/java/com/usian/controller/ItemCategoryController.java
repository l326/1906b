package com.usian.controller;

import com.usian.feign.ItemServiceFeign;
import com.usian.utlis.CatResult;
import com.usian.utlis.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 首页商品分类
 */
@RestController
@RequestMapping("/frontend/itemCategory")
public class ItemCategoryController {
    @Autowired
    private ItemServiceFeign itemServiceFeign;

    /**
     * 查询首页商品分类
     */
    @RequestMapping("/selectItemCategoryAll")
    public Result selectItemCategoryAll() {
        CatResult catNodeslist = itemServiceFeign.selectItemCategoryAll();
        if(catNodeslist.getData().size()>0){
            return Result.ok(catNodeslist);
        }
        return Result.error("查无结果");
    }
}