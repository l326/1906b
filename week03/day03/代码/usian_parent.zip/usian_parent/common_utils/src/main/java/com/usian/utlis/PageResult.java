package com.usian.utlis;

import java.io.Serializable;
import java.util.List;

public class PageResult implements Serializable {
    private Integer pageIndex;//当前页
    private Long totalpage;//总页数
    private List result;//结果集

    public Integer getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(Integer pageIndex) {
        this.pageIndex = pageIndex;
    }

    public Long getTotalpage() {
        return totalpage;
    }

    public void setTotalpage(Long totalpage) {
        this.totalpage = totalpage;
    }

    public List getResult() {
        return result;
    }

    public void setResult(List result) {
        this.result = result;
    }
}
