package com.usian.service;

import com.usian.pojo.OrderInfo;

public interface OrderService {
    String insertOrder(OrderInfo orderInfo);
}
