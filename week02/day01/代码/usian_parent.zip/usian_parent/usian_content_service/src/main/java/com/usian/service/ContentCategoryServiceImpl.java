package com.usian.service;

import com.usian.mapper.TbContentCategoryMapper;
import com.usian.pojo.TbContentCategory;
import com.usian.pojo.TbContentCategoryExample;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * 内容分类业务层
 */
@Service
@Transactional
public class ContentCategoryServiceImpl implements ContentCategoryService {

    @Autowired
    private TbContentCategoryMapper tbContentCategoryMapper;

    /**
     * 根据父节点id 查询子节点
     * @param parentId
     * @return
     */
    @Override
    public List<TbContentCategory> selectContentCategoryByParentId(Long parentId) {
        TbContentCategoryExample tbContentCategoryExample = new TbContentCategoryExample();
        TbContentCategoryExample.Criteria criteria = tbContentCategoryExample.createCriteria();
        criteria.andParentIdEqualTo(parentId);
        List<TbContentCategory> list = tbContentCategoryMapper.selectByExample(tbContentCategoryExample);
        return list;
    }

    /**
     * 添加
     * @param tbContentCategory
     * @return
     */
    @Override
    public Integer insertContentCategory(TbContentCategory tbContentCategory) {
        //补全数据库中数据
        tbContentCategory.setCreated(new Date());
        tbContentCategory.setUpdated(new Date());
        tbContentCategory.setIsParent(false);
        tbContentCategory.setSortOrder(1);
        tbContentCategory.setStatus(1);
        //添加数据
        Integer i = tbContentCategoryMapper.insert(tbContentCategory);
        //查询添加节点的父节点
        TbContentCategory ContentCategory = tbContentCategoryMapper.selectByPrimaryKey(tbContentCategory.getParentId());
        //判断父节点是否是子叶节点
        if(!ContentCategory.getIsParent()){
            ContentCategory.setIsParent(true);
            ContentCategory.setUpdated(new Date());
            tbContentCategoryMapper.updateByPrimaryKey(ContentCategory);
        }
        return i;
    }

    /**
     * 删除
     * @param categoryId
     * @return
     */
    @Override
    public Integer deleteContentCategoryById(Long categoryId) {
        //查询要删除的当前节点
        TbContentCategory tbContentCategory = tbContentCategoryMapper.selectByPrimaryKey(categoryId);
        //判断当前节点是否有父节点
        if(tbContentCategory.getIsParent()==true){
            return 0;
        }
        //删除当前节点
        tbContentCategoryMapper.deleteByPrimaryKey(categoryId);
        //查询当前节点有无兄弟节点
        TbContentCategoryExample tbContentCategoryExample = new TbContentCategoryExample();
        TbContentCategoryExample.Criteria criteria = tbContentCategoryExample.createCriteria();
        criteria.andParentIdEqualTo(tbContentCategory.getParentId());
        List<TbContentCategory> tbContentCategoryList = tbContentCategoryMapper.selectByExample(tbContentCategoryExample);
        //如果当前节点没有其他兄弟节点，就修改当前节点父节点的isParent为false
        if(tbContentCategoryList.size()==0){
            TbContentCategory category = new TbContentCategory();
            category.setId(tbContentCategory.getParentId());
            category.setUpdated(new Date());
            category.setIsParent(false);
            tbContentCategoryMapper.updateByPrimaryKeySelective(category);
        }
        return 1;
    }

    /**
     * 修改
     * @param tbContentCategory
     * @return
     */
    @Override
    public Integer updateContentCategory(TbContentCategory tbContentCategory) {
        tbContentCategory.setUpdated(new Date());
        tbContentCategoryMapper.updateByPrimaryKeySelective(tbContentCategory);
        return 200;
    }
}
