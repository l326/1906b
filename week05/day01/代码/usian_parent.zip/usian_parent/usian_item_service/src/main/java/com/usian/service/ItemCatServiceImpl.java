package com.usian.service;

import com.usian.mapper.TbItemCatMapper;
import com.usian.pojo.TbItemCat;
import com.usian.pojo.TbItemCatExample;
import com.usian.redis.RedisClient;
import com.usian.utlis.CatNode;
import com.usian.utlis.CatResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
@Service
@Transactional
public class ItemCatServiceImpl implements ItemCatService {

    @Autowired
    private TbItemCatMapper tbItemCatMapper;

    @Value("${portal_catresult_redis_key}")
    private String portal_catresult_redis_key;

    @Autowired
    private RedisClient redisClient;

    /**
     * 根据id查询商品类目
     * @param id
     * @return
     */
    @Override
    public List<TbItemCat> selectItemCategoryByParentId(Long id) {
        TbItemCatExample tbItemCatExample = new TbItemCatExample();
        TbItemCatExample.Criteria criteria = tbItemCatExample.createCriteria();
        criteria.andStatusEqualTo(1);
        criteria.andParentIdEqualTo(id);
        if (id!=0){
            int a = 6 / 0;
        }
        return tbItemCatMapper.selectByExample(tbItemCatExample);
    }

    /**
     * 查询首页商品分类
     * @return
     */
    @Override
    public CatResult selectItemCategoryAll() {
        //查询缓存
        CatResult catResultRedis = (CatResult)redisClient.get(portal_catresult_redis_key);
        if(catResultRedis!=null){
            //如果Redis有,直接retuen
            return catResultRedis;
        }


        //如果Redis没有，则查询数据库并把结果放到Redis中
        //因为一级菜单有子菜单，子菜单有子子菜单，所以要递归调用
        List catlist = getCatlist(0L);
        CatResult catResult = new CatResult();
        catResult.setData(catlist);
        redisClient.set(portal_catresult_redis_key,catResult);
        return catResult;
    }

    private List getCatlist(Long parentId){
        //2.把查询结果装载到List<CatNode>,并且只装18次
        TbItemCatExample tbItemCatExample = new TbItemCatExample();
        TbItemCatExample.Criteria criteria = tbItemCatExample.createCriteria();
        criteria.andParentIdEqualTo(parentId);
        List<TbItemCat> tbItemCatList = tbItemCatMapper.selectByExample(tbItemCatExample);

        //拼接catnode
        List catNodeList = new ArrayList();
        int count = 0;
        for (int i = 0; i < tbItemCatList.size(); i++){
            TbItemCat tbItemCat = tbItemCatList.get(i);
            //该类目是父节点
            if (tbItemCat.getIsParent()){
                CatNode catNode = new CatNode();
                catNode.setName(tbItemCat.getName());
                catNode.setItem(getCatlist(tbItemCat.getId()));
                catNodeList.add(catNode);
                count = count + 1;
                if (count == 18){
                    break;
                }
            }else{
                //该节点不是父节点，直接把类目名称添加到catnodelist
                catNodeList.add(tbItemCat.getName());
            }
        }
        return catNodeList;
    }
}

